class Plant:
    def _init_ (self,name,health,damage):
        self.name = str
        self.health = int
        self.damage = int

    def attack(self,zombie):
        if self.health > 0:
            print(f"{self.name}, attacks -> {self.damage} damage")
        zombie.take_damage
    def take_damage(self,amount):
        self.health = max(0, self.health - amount)
        

class Zombie:
    def __init__(self,name,health,damage,distance):
        self.name = str
        self.health = int 
        self.damage = int
        self.distance = int

    def move(self):
        if self.distance > 0:
            self.distance -= 1
            print("zombie moves closer, distance : {self.distance}")

    def attack(self,plant):
        print("Zombie attack, dealt {self.damage} damage")
        plant.take_damage
    def take_damage(self,amount):


def show(p1,p2,z):
    print(f"{p1.name}: {p1.health} HP, {p2.name}: {p2.health} HP")
    print(f"Zombie: {z.health}, {z.distance}")

def game_over(p1,p2,z):
    if z.health <= 0:
        print("plant win")
        return True
    if p1.health <= 0 and p2.health <=0:
        print("zombie win")
        return True
    return False

PeaShooter = Plant("peashooter", 100, 20)
Repeater = Plant("repeater",80,30)
zombie = Zombie("zombie",150,25,5)


print("Plants VS Zombies")

while True:
        if PeaShooter.health > 0:
            PeaShooter.attack(zombie)
            show(PeaShooter,Repeater,zombie)
            if game_over(PeaShooter,Repeater,zombie):
                break

        if Repeater.health > 0:
            Repeater.attack(zombie)
            show(PeaShooter,Repeater,zombie)
            if game_over(PeaShooter,Repeater,zombie):
                break

        if zombie.distance > 0:
            zombie.move
        else:
            if PeaShooter.health > 0:
                zombie.attack(PeaShooter)
            elif Repeater.health > 0:
                zombie.attack(Repeater)
        show(PeaShooter,Repeater,zombie)
        if game_over(PeaShooter,Repeater,zombie):break
    

